import Link from "next/link";
import { TrackingSearch } from "@/components/tracking-search";
import { COMPANY_DOMAIN, COMPANY_NAME, formatLek, OPERATING_CITY_NAMES } from "@/lib/constants";
import { getCurrentUser } from "@/lib/auth";
import { getPricingSnapshot, getPublicStatusSnapshot } from "@/lib/store";

export default async function Home() {
  const user = await getCurrentUser();
  const pricing = await getPricingSnapshot();
  const status = await getPublicStatusSnapshot();

  return (
    <main className="flex-1">
      <div className="mx-auto max-w-7xl px-6 pb-24 pt-6 lg:px-10">
        <nav className="flex flex-col gap-4 rounded-full border border-black/6 bg-white/60 px-5 py-4 backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--panel)] text-[var(--surface-strong)] shadow-[0_18px_40px_rgba(13,25,35,0.18)]">
              <span className="font-heading text-lg font-semibold tracking-[0.12em]">SE</span>
            </div>
            <div>
              <p className="font-heading text-sm uppercase tracking-[0.22em] text-[var(--foreground)]">
                {COMPANY_NAME}
              </p>
              <p className="text-sm text-[var(--muted)]">{COMPANY_DOMAIN}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-sm">
            <a
              href="#cmimet"
              className="rounded-full border border-black/8 px-4 py-2 text-[var(--foreground)] transition hover:bg-white"
            >
              Tarifat
            </a>
            <a
              href="#si-punon"
              className="rounded-full border border-black/8 px-4 py-2 text-[var(--foreground)] transition hover:bg-white"
            >
              Si punon
            </a>
            <Link
              href={user ? (user.role === "admin" ? "/center" : "/portal") : "/auth"}
              className="rounded-full bg-[var(--panel)] px-4 py-2 text-[var(--surface-strong)] transition hover:bg-[var(--panel-soft)]"
            >
              {user ? "Hap panelin" : "Regjistrohu / Hyr"}
            </Link>
          </div>
        </nav>

        <section className="mt-10 grid gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.34em] text-[var(--accent)]">
              Platforme dergesash ne kohe reale
            </p>
            <h1 className="mt-6 max-w-5xl font-heading text-5xl leading-[1.02] font-semibold text-[var(--foreground)] sm:text-6xl">
              Web faqe dhe sistem pune per biznesin e dergesave te{" "}
              <span className="text-[var(--accent)]">Sfera Express Delivery</span>.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-[var(--muted)]">
              Bizneset regjistrohen me email ose Gmail, krijojne profilin e tyre, hapin
              dergesa, marrin kod gjurmimi dhe ndjekin produktin ne kohe reale. Qendra
              operative merr njoftimet direkt dhe menaxhon tarifat sipas qytetit.
            </p>

            <div className="mt-8 flex flex-col gap-4 sm:flex-row">
              <Link
                href="/auth"
                className="inline-flex items-center justify-center rounded-full bg-[var(--panel)] px-6 py-3.5 text-sm font-semibold text-[var(--surface-strong)] transition hover:bg-[var(--panel-soft)]"
              >
                Regjistro biznesin
              </Link>
              <Link
                href="/center"
                className="inline-flex items-center justify-center rounded-full border border-black/8 bg-white/60 px-6 py-3.5 text-sm font-semibold text-[var(--foreground)] backdrop-blur-sm transition hover:bg-white"
              >
                Paneli i qendres
              </Link>
            </div>

            <div className="mt-12 grid gap-4 sm:grid-cols-3">
              <article className="rounded-[1.75rem] border border-black/6 bg-white/78 p-5 shadow-[0_18px_60px_rgba(25,38,48,0.08)] backdrop-blur-sm">
                <p className="font-heading text-4xl font-semibold text-[var(--foreground)]">
                  {status.businesses}
                </p>
                <p className="mt-3 text-sm font-semibold uppercase tracking-[0.16em] text-[var(--foreground)]">
                  biznese
                </p>
                <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
                  te regjistruara ne sistem
                </p>
              </article>
              <article className="rounded-[1.75rem] border border-black/6 bg-white/78 p-5 shadow-[0_18px_60px_rgba(25,38,48,0.08)] backdrop-blur-sm">
                <p className="font-heading text-4xl font-semibold text-[var(--foreground)]">
                  {status.activeShipments}
                </p>
                <p className="mt-3 text-sm font-semibold uppercase tracking-[0.16em] text-[var(--foreground)]">
                  dergesa aktive
                </p>
                <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
                  te menaxhuara nga qendra operative
                </p>
              </article>
              <article className="rounded-[1.75rem] border border-black/6 bg-white/78 p-5 shadow-[0_18px_60px_rgba(25,38,48,0.08)] backdrop-blur-sm">
                <p className="font-heading text-4xl font-semibold text-[var(--foreground)]">
                  {OPERATING_CITY_NAMES.length}
                </p>
                <p className="mt-3 text-sm font-semibold uppercase tracking-[0.16em] text-[var(--foreground)]">
                  qytete
                </p>
                <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
                  operative per momentin
                </p>
              </article>
            </div>
          </div>

          <div className="space-y-5">
            <TrackingSearch />

            <section className="rounded-[2rem] border border-white/12 bg-[var(--panel)] p-7 text-white shadow-[0_28px_90px_rgba(8,14,24,0.24)]">
              <p className="font-mono text-xs uppercase tracking-[0.32em] text-white/55">
                Cfare merr biznesi
              </p>
              <div className="mt-6 grid gap-4">
                {[
                  "Profil biznesi me te dhenat e plota dhe ikon profile ne panel.",
                  "Buton plus ne qender poshte per krijimin e dergeses se re.",
                  "Kod gjurmimi per biznesin dhe klientin final.",
                  "Njoftim direkt ne qender per pickup, dorezim dhe koordinim.",
                ].map((item) => (
                  <article
                    key={item}
                    className="rounded-[1.5rem] border border-white/10 bg-white/6 p-4 text-sm leading-6 text-white/75"
                  >
                    {item}
                  </article>
                ))}
              </div>
            </section>

            <section className="rounded-[2rem] border border-black/6 bg-white/78 p-7 shadow-[0_18px_60px_rgba(25,38,48,0.08)] backdrop-blur-sm">
              <p className="font-mono text-xs uppercase tracking-[0.32em] text-[var(--accent)]">
                sferaexpress.al
              </p>
              <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
                Kerkim publik per biznesin dhe klientin final
              </h2>
              <p className="mt-4 text-sm leading-7 text-[var(--muted)]">
                Cdo kod gjurmimi hap nje faqe publike ku shihet statusi, vendndodhja
                GPS, historiku i levizjes dhe destinacioni final. Kjo i sherben si
                biznesit ashtu edhe klientit ne kohe reale.
              </p>
            </section>
          </div>
        </section>

        <section id="si-punon" className="mt-24 grid gap-6 lg:grid-cols-4">
          {[
            {
              step: "01",
              title: "Regjistrim biznesi",
              text: "Biznesi fut emrin, qytetin, telefonin, email-in dhe adresen e sakte.",
            },
            {
              step: "02",
              title: "Krijim dergese",
              text: "Nga butoni plus plotesohen te dhenat e biznesit, pajtueshmeria dhe me pas klienti final.",
            },
            {
              step: "03",
              title: "Qendra merr njoftim",
              text: "Sistemi e dergon kerkesen ne qender dhe lidhet direkt me operacionet e Sfera Express.",
            },
            {
              step: "04",
              title: "Tracking ne kohe reale",
              text: "Gjenerohet kodi i gjurmimit dhe mund te lidhet me GPS ose me perditesime operative.",
            },
          ].map((item) => (
            <article
              key={item.step}
              className="rounded-[2rem] border border-black/6 bg-white/78 p-6 shadow-[0_20px_70px_rgba(25,38,48,0.08)] backdrop-blur-sm"
            >
              <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
                {item.step}
              </p>
              <h2 className="mt-4 font-heading text-2xl font-semibold text-[var(--foreground)]">
                {item.title}
              </h2>
              <p className="mt-4 text-sm leading-7 text-[var(--muted)]">{item.text}</p>
            </article>
          ))}
        </section>

        <section id="cmimet" className="mt-24 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-[2rem] border border-black/6 bg-white/78 p-8 shadow-[0_20px_70px_rgba(25,38,48,0.08)] backdrop-blur-sm">
            <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
              Tarifat per qytet
            </p>
            <h2 className="mt-4 font-heading text-4xl font-semibold text-[var(--foreground)]">
              Kosto automatike sapo zgjidhet destinacioni
            </h2>
            <p className="mt-4 text-base leading-7 text-[var(--muted)]">
              Ne formularin e dergeses, biznesi zgjedh qytetin dhe sistemi i shfaq menjehere
              cmimin qe duhet te paguaje ne momentin e pickup-it. Tarifat mund te
              ndryshohen nga qendra operative ne cdo kohe.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {pricing.map((item) => (
              <article
                key={item.city}
                className="rounded-[1.75rem] border border-black/6 bg-white/78 p-5 shadow-[0_18px_60px_rgba(25,38,48,0.08)] backdrop-blur-sm"
              >
                <p className="font-heading text-2xl font-semibold text-[var(--foreground)]">
                  {item.city}
                </p>
                <p className="mt-3 text-3xl font-semibold text-[var(--accent)]">
                  {formatLek(item.price)}
                </p>
                <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
                  Pragu jeshil per nisje rruge: {item.threshold} porosi aktive.
                </p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
