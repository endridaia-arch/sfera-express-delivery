import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { SHIPMENT_STATUSES, TELEMETRY_API_KEY } from "@/lib/constants";
import { updateShipmentProgress } from "@/lib/store";

function readString(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function readNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  const apiKey = request.headers.get("x-sfera-api-key");

  if (!user && apiKey !== TELEMETRY_API_KEY) {
    return NextResponse.json(
      { error: "Mungon autentikimi ose API key." },
      { status: 401 },
    );
  }

  if (user && user.role !== "admin" && apiKey !== TELEMETRY_API_KEY) {
    return NextResponse.json({ error: "Vetem qendra mund ta perdore kete endpoint." }, { status: 403 });
  }

  const body = (await request.json()) as Record<string, unknown>;
  const status = readString(body.status);

  try {
    const shipment = await updateShipmentProgress({
      trackingCode: readString(body.trackingCode),
      status: SHIPMENT_STATUSES.includes(status as (typeof SHIPMENT_STATUSES)[number])
        ? (status as (typeof SHIPMENT_STATUSES)[number])
        : undefined,
      location: readString(body.location) || undefined,
      note: readString(body.note) || undefined,
      lat: readNumber(body.lat),
      lng: readNumber(body.lng),
    });

    return NextResponse.json({
      trackingCode: shipment.trackingCode,
      status: shipment.status,
      currentLocation: shipment.currentLocation,
      currentLat: shipment.currentLat,
      currentLng: shipment.currentLng,
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Telemetry update nuk u pranua.",
      },
      { status: 400 },
    );
  }
}
