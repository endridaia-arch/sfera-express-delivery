import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { isOperatingCity } from "@/lib/constants";
import { createShipmentForBusiness } from "@/lib/store";

function readString(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "business") {
    return NextResponse.json({ error: "Duhet te jesh i loguar si biznes." }, { status: 401 });
  }

  const body = (await request.json()) as Record<string, unknown>;
  const businessCity = readString(body.businessCity);
  const destinationCity = readString(body.destinationCity);

  if (!isOperatingCity(businessCity) || !isOperatingCity(destinationCity)) {
    return NextResponse.json(
      { error: "Qyteti i zgjedhur nuk mbeshtetet nga Sfera Express." },
      { status: 400 },
    );
  }

  try {
    const shipment = await createShipmentForBusiness(user, {
      businessName: readString(body.businessName),
      businessEmail: readString(body.businessEmail),
      businessPhone: readString(body.businessPhone),
      businessCity,
      businessAddress: readString(body.businessAddress),
      complianceAccepted: Boolean(body.complianceAccepted),
      customerName: readString(body.customerName),
      customerPhone: readString(body.customerPhone),
      customerEmail: readString(body.customerEmail),
      destinationCity,
      destinationAddress: readString(body.destinationAddress),
    });

    return NextResponse.json({
      trackingCode: shipment.trackingCode,
      price: shipment.price,
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Dergesa nuk mund te krijohej.",
      },
      { status: 400 },
    );
  }
}
