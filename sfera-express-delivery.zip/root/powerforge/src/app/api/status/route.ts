import { NextResponse } from "next/server";
import { getPublicStatusSnapshot } from "@/lib/store";

export async function GET() {
  return NextResponse.json(await getPublicStatusSnapshot());
}
