import { CenterPricingForm } from "@/components/center-pricing-form";
import { LiveCenterBoard } from "@/components/live-center-board";
import { ShipmentProgressForm } from "@/components/shipment-progress-form";
import { LogoutButton } from "@/components/logout-button";
import { TELEMETRY_API_KEY } from "@/lib/constants";
import { requireAdminUser } from "@/lib/auth";
import { getCenterSnapshot } from "@/lib/store";

export default async function CenterPage() {
  await requireAdminUser();
  const snapshot = await getCenterSnapshot();

  return (
    <main className="flex-1">
      <div className="mx-auto max-w-7xl px-6 pb-24 pt-6 lg:px-10">
        <nav className="flex flex-col gap-4 rounded-full border border-black/6 bg-white/60 px-5 py-4 backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--panel)] text-[var(--surface-strong)] shadow-[0_18px_40px_rgba(13,25,35,0.18)]">
              <span className="font-heading text-lg font-semibold tracking-[0.12em]">SE</span>
            </div>
            <div>
              <p className="font-heading text-sm uppercase tracking-[0.22em] text-[var(--foreground)]">
                Sfera Express Delivery
              </p>
              <p className="text-sm text-[var(--muted)]">Qendra operative</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <a
              href="#tarifat"
              className="rounded-full border border-black/8 px-4 py-2 text-[var(--foreground)] transition hover:bg-white"
            >
              Tarifat
            </a>
            <a
              href="#dergesat"
              className="rounded-full border border-black/8 px-4 py-2 text-[var(--foreground)] transition hover:bg-white"
            >
              Dergesat
            </a>
            <LogoutButton />
          </div>
        </nav>

        <section className="mt-10">
          <LiveCenterBoard initialSnapshot={snapshot} />
        </section>

        <section id="tarifat" className="mt-16 rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
            Menaxhimi i tarifave
          </p>
          <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
            Ndrysho cmimet per cdo qytet
          </h2>
          <p className="mt-4 max-w-3xl text-base leading-7 text-[var(--muted)]">
            Tarifa shfaqet automatikisht te biznesi sapo zgjidhet qyteti i destinacionit.
            Pragu jeshil kontrollon momentin kur duhet nisur patjeter rrugëtimi drejt atij qyteti.
          </p>
          <div className="mt-8">
            <CenterPricingForm pricing={snapshot.pricing} />
          </div>
        </section>

        <section className="mt-16 rounded-[2rem] border border-white/12 bg-[var(--panel)] p-8 text-white shadow-[0_28px_90px_rgba(8,14,24,0.24)]">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-white/55">
            GPS / telemetry
          </p>
          <h2 className="mt-4 font-heading text-3xl font-semibold">
            Endpoint per pajisje ose integrim GPS
          </h2>
          <p className="mt-4 max-w-3xl text-base leading-7 text-white/72">
            Per lidhje me GPS reale, pajisja ose sistemi i makines mund te beje POST te
            `/api/telemetry` me `trackingCode`, `status`, `location`, `lat`, `lng` dhe
            header-in `x-sfera-api-key`.
          </p>
          <pre className="mt-6 overflow-x-auto rounded-[1.75rem] border border-white/10 bg-black/12 p-5 font-mono text-sm leading-7 text-white/82">
{`POST /api/telemetry
x-sfera-api-key: ${TELEMETRY_API_KEY}
{
  "trackingCode": "SFE-TIR-AB12CD",
  "status": "Ne tranzit",
  "location": "Afer autostrades Tirane - Durres",
  "lat": 41.2902,
  "lng": 19.6321,
  "note": "Pakoja eshte ne makinen e shpërndarjes"
}`}
          </pre>
        </section>

        <section id="dergesat" className="mt-16 rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
            Operacionet
          </p>
          <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
            Perditeso statusin e dergesave
          </h2>

          <div className="mt-8 grid gap-5">
            {snapshot.activeShipments.length === 0 ? (
              <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5">
                <p className="text-sm leading-6 text-[var(--muted)]">
                  Nuk ka dergesa aktive per momentin.
                </p>
              </article>
            ) : (
              snapshot.activeShipments.map((shipment) => (
                <article
                  key={shipment.id}
                  className="rounded-[1.75rem] border border-black/6 bg-[var(--surface-strong)] p-6"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <p className="font-heading text-2xl font-semibold text-[var(--foreground)]">
                        {shipment.businessName}
                      </p>
                      <p className="mt-2 text-sm text-[var(--muted)]">
                        Destinacion: {shipment.destinationCity} / {shipment.customerName}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono text-sm uppercase tracking-[0.22em] text-[var(--accent)]">
                        {shipment.trackingCode}
                      </p>
                      <p className="mt-2 text-sm text-[var(--muted)]">{shipment.status}</p>
                    </div>
                  </div>
                  <div className="mt-6">
                    <ShipmentProgressForm shipment={shipment} />
                  </div>
                </article>
              ))
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
