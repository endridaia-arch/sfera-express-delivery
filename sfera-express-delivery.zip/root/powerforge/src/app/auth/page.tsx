import { redirect } from "next/navigation";
import { AuthForms } from "@/components/auth-forms";
import { getCurrentUser } from "@/lib/auth";

export default async function AuthPage() {
  const user = await getCurrentUser();
  if (user) {
    redirect(user.role === "admin" ? "/center" : "/portal");
  }

  return (
    <main className="flex-1">
      <div className="mx-auto max-w-6xl px-6 pb-24 pt-10 lg:px-10">
        <section className="mb-10 max-w-3xl">
          <p className="font-mono text-xs uppercase tracking-[0.34em] text-[var(--accent)]">
            Regjistrim dhe login
          </p>
          <h1 className="mt-5 font-heading text-5xl font-semibold leading-[1.04] text-[var(--foreground)]">
            Hyr ne ekosistemin e Sfera Express Delivery.
          </h1>
          <p className="mt-5 text-lg leading-8 text-[var(--muted)]">
            Biznesi regjistrohet me email ose Gmail, krijon profilin e vet dhe menaxhon
            dergesat. Qendra operative futet nga i njejti panel, por me llogarine admin.
          </p>
        </section>

        <AuthForms />
      </div>
    </main>
  );
}
