import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex flex-1 items-center justify-center px-6 py-20">
      <div className="max-w-xl rounded-[2rem] border border-black/6 bg-white/82 p-10 text-center shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
          Nuk u gjet
        </p>
        <h1 className="mt-5 font-heading text-4xl font-semibold text-[var(--foreground)]">
          Faqja ose kodi i gjurmimit nuk ekziston.
        </h1>
        <p className="mt-5 text-base leading-7 text-[var(--muted)]">
          Kontrollo tracking code ose kthehu ne faqen kryesore per te kerkuar serish.
        </p>
        <div className="mt-8 flex justify-center">
          <Link
            href="/"
            className="rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)]"
          >
            Kthehu ne home
          </Link>
        </div>
      </div>
    </main>
  );
}
