import { ShipmentWizard } from "@/components/shipment-wizard";
import { requireBusinessUser } from "@/lib/auth";
import { getPricingSnapshot } from "@/lib/store";

export default async function PortalCreatePage() {
  const user = await requireBusinessUser();
  const pricing = await getPricingSnapshot();

  return (
    <div className="mt-10 grid gap-6 lg:grid-cols-[0.84fr_1.16fr]">
      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
          Hap porosi te re
        </p>
        <h1 className="mt-4 font-heading text-4xl font-semibold text-[var(--foreground)]">
          Krijo dergesen me dy hapa
        </h1>
        <p className="mt-5 text-base leading-7 text-[var(--muted)]">
          Hapi i pare ploteson te dhenat e biznesit dhe pajtueshmerine. Hapi i dyte
          ploteson klientin final, qytetin e destinacionit dhe koston automatike.
        </p>
      </section>

      <ShipmentWizard user={user} pricing={pricing} />
    </div>
  );
}
