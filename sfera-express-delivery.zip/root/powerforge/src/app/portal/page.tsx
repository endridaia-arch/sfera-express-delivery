import Link from "next/link";
import { formatLek } from "@/lib/constants";
import { requireBusinessUser } from "@/lib/auth";
import { getBusinessShipments, getPricingSnapshot } from "@/lib/store";

export default async function PortalPage() {
  const user = await requireBusinessUser();
  const shipments = await getBusinessShipments(user.id);
  const pricing = await getPricingSnapshot();
  const activeShipments = shipments.filter((shipment) => shipment.status !== "Dorezuar");

  return (
    <div className="mt-10 grid gap-6">
      <section className="grid gap-6 lg:grid-cols-[0.98fr_1.02fr]">
        <div className="rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
            Miresevjen
          </p>
          <h1 className="mt-4 font-heading text-4xl font-semibold text-[var(--foreground)]">
            {user.businessName}
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-[var(--muted)]">
            Ketu menaxhon profilin, krijon dergesa te reja dhe kontrollon tracking code
            per secilen porosi. Ikona e profilit ndodhet ne te djathte lart dhe butoni
            plus ne qender poshte.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5">
              <p className="text-sm text-[var(--muted)]">Dergesa aktive</p>
              <p className="mt-2 font-heading text-4xl font-semibold text-[var(--foreground)]">
                {activeShipments.length}
              </p>
            </article>
            <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5">
              <p className="text-sm text-[var(--muted)]">Dergesa totale</p>
              <p className="mt-2 font-heading text-4xl font-semibold text-[var(--foreground)]">
                {shipments.length}
              </p>
            </article>
            <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5">
              <p className="text-sm text-[var(--muted)]">Qyteti yt</p>
              <p className="mt-2 font-heading text-4xl font-semibold text-[var(--foreground)]">
                {user.city}
              </p>
            </article>
          </div>
        </div>

        <div className="rounded-[2rem] border border-white/12 bg-[var(--panel)] p-8 text-white shadow-[0_28px_90px_rgba(8,14,24,0.24)]">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-white/55">
            Tarifat operative
          </p>
          <h2 className="mt-4 font-heading text-3xl font-semibold">Cmimet sipas qytetit</h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {pricing.map((item) => (
              <article
                key={item.city}
                className="rounded-[1.5rem] border border-white/10 bg-white/6 p-4"
              >
                <p className="font-heading text-xl font-semibold">{item.city}</p>
                <p className="mt-3 text-sm text-white/68">{formatLek(item.price)}</p>
                <p className="mt-3 text-xs uppercase tracking-[0.2em] text-white/50">
                  pragu jeshil {item.threshold}
                </p>
              </article>
            ))}
          </div>
          <p className="mt-6 text-sm leading-6 text-white/70">
            Sapo zgjedh qytetin e klientit ne porosi, sistemi shfaq automatikisht
            koston qe paguhet ne pickup. Kur qyteti kalon pragun e vendosur, qendra e
            sheh me sinjal jeshil dhe nis planifikimin e rruges.
          </p>
        </div>
      </section>

      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
              Dergesat e biznesit
            </p>
            <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
              Lista e porosive
            </h2>
          </div>
          <Link
            href="/portal/create"
            className="rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)]"
          >
            Krijo dergese
          </Link>
        </div>

        <div className="mt-8 grid gap-4">
          {shipments.length === 0 ? (
            <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-6">
              <p className="text-sm leading-6 text-[var(--muted)]">
                Nuk ke krijuar ende dergesa. Perdore butonin plus ne fund per te hapur
                porosine e pare.
              </p>
            </article>
          ) : (
            shipments.map((shipment) => (
              <article
                key={shipment.id}
                className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5"
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="font-heading text-2xl font-semibold text-[var(--foreground)]">
                      {shipment.customerName}
                    </p>
                    <p className="mt-2 text-sm text-[var(--muted)]">
                      {shipment.destinationCity} / {shipment.destinationAddress}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-mono text-sm uppercase tracking-[0.22em] text-[var(--accent)]">
                      {shipment.trackingCode}
                    </p>
                    <p className="mt-2 text-sm text-[var(--muted)]">{shipment.status}</p>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-4 text-sm">
                  <p className="text-[var(--muted)]">
                    Kosto: <span className="font-semibold text-[var(--foreground)]">{formatLek(shipment.price)}</span>
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <Link
                      href={`/track/${shipment.trackingCode}`}
                      className="rounded-full border border-black/8 px-4 py-2 font-semibold text-[var(--foreground)] transition hover:bg-white"
                    >
                      Ndiq produktin
                    </Link>
                  </div>
                </div>
              </article>
            ))
          )}
        </div>
      </section>
    </div>
  );
}
