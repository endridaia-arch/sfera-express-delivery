import { ProfileForm } from "@/components/profile-form";
import { requireBusinessUser } from "@/lib/auth";

export default async function PortalProfilePage() {
  const user = await requireBusinessUser();

  return (
    <div className="mt-10 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
          Profili i biznesit
        </p>
        <h1 className="mt-4 font-heading text-4xl font-semibold text-[var(--foreground)]">
          Perditeso te dhenat
        </h1>
        <p className="mt-5 text-base leading-7 text-[var(--muted)]">
          Ketu kontrollon emrin e biznesit, email-in, numrin e telefonit, qytetin dhe
          adresen e sakte. Keto te dhena dalin ne dergesat e reja si fusha te
          paraplotësuara.
        </p>
      </section>

      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
        <ProfileForm user={user} />
      </section>
    </div>
  );
}
