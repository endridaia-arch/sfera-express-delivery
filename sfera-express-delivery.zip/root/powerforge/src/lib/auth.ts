import { randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { SESSION_COOKIE } from "@/lib/constants";
import {
  createSession,
  deleteSession,
  getUserBySession,
  type UserRecord,
} from "@/lib/store";

export async function getCurrentUser() {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) {
    return null;
  }

  return getUserBySession(token);
}

export async function requireAuthenticatedUser() {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/auth");
  }
  return user;
}

export async function requireBusinessUser() {
  const user = await requireAuthenticatedUser();
  if (user.role !== "business") {
    redirect("/center");
  }
  return user;
}

export async function requireAdminUser() {
  const user = await requireAuthenticatedUser();
  if (user.role !== "admin") {
    redirect("/portal");
  }
  return user;
}

export async function signInUser(user: UserRecord) {
  const token = randomBytes(32).toString("hex");
  await createSession(user.id, token);

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function signOutCurrentUser() {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (token) {
    await deleteSession(token);
  }
  cookieStore.delete(SESSION_COOKIE);
}
