export const OPERATING_CITIES = [
  { name: "Tirane", lat: 41.3275, lng: 19.8187, basePrice: 250, threshold: 25 },
  { name: "Elbasan", lat: 41.1125, lng: 20.0822, basePrice: 320, threshold: 25 },
  { name: "Lushnje", lat: 40.9419, lng: 19.705, basePrice: 350, threshold: 25 },
  { name: "Fier", lat: 40.7239, lng: 19.556, basePrice: 380, threshold: 25 },
  { name: "Vlore", lat: 40.4661, lng: 19.4914, basePrice: 450, threshold: 25 },
  { name: "Durres", lat: 41.3231, lng: 19.4414, basePrice: 300, threshold: 25 },
  { name: "Sarande", lat: 39.8756, lng: 20.0053, basePrice: 650, threshold: 25 },
] as const;

export const OPERATING_CITY_NAMES = OPERATING_CITIES.map((city) => city.name);

export const COMPANY_NAME = "Sfera Express Delivery";
export const COMPANY_DOMAIN = "sferaexpress.al";
export const SESSION_COOKIE = "sfera_session";
export const DEFAULT_ADMIN_EMAIL =
  process.env.SFERA_ADMIN_EMAIL || "admin@sferaexpress.al";
export const DEFAULT_ADMIN_PASSWORD =
  process.env.SFERA_ADMIN_PASSWORD || "SferaAdmin2026!";
export const TELEMETRY_API_KEY =
  process.env.SFERA_TELEMETRY_KEY || "local-sfera-telemetry-key";

export const SHIPMENT_STATUSES = [
  "Kerkese e re",
  "Pickup i planifikuar",
  "Ne tranzit",
  "Ne qytetin e destinacionit",
  "Ne dorezim",
  "Dorezuar",
] as const;

export type OperatingCityName = (typeof OPERATING_CITY_NAMES)[number];
export type ShipmentStatus = (typeof SHIPMENT_STATUSES)[number];

export function isOperatingCity(value: string): value is OperatingCityName {
  return OPERATING_CITY_NAMES.includes(value as OperatingCityName);
}

export function getCityConfig(city: OperatingCityName) {
  return OPERATING_CITIES.find((item) => item.name === city)!;
}

export function formatLek(value: number) {
  return `${Math.round(value)} ALL`;
}

export function cityCode(city: string) {
  return city.slice(0, 3).toUpperCase();
}
