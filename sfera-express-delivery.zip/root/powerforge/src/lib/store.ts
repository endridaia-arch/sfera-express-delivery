import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import {
  DEFAULT_ADMIN_EMAIL,
  DEFAULT_ADMIN_PASSWORD,
  OPERATING_CITIES,
  OPERATING_CITY_NAMES,
  SHIPMENT_STATUSES,
  cityCode,
  getCityConfig,
  isOperatingCity,
  type OperatingCityName,
  type ShipmentStatus,
} from "@/lib/constants";
import { hashPassword, verifyPassword } from "@/lib/password";

const DATA_DIR = join(process.cwd(), "data");
const DATA_FILE = join(DATA_DIR, "sfera-express-store.json");

export type UserRole = "admin" | "business";

export type UserRecord = {
  id: string;
  role: UserRole;
  contactName: string;
  businessName: string;
  email: string;
  passwordHash: string;
  phone: string;
  city: OperatingCityName;
  address: string;
  createdAt: string;
};

export type SessionRecord = {
  id: string;
  userId: string;
  token: string;
  createdAt: string;
};

export type PricingRecord = {
  city: OperatingCityName;
  price: number;
  threshold: number;
};

export type ShipmentRecord = {
  id: string;
  trackingCode: string;
  businessId: string;
  businessName: string;
  businessEmail: string;
  businessPhone: string;
  businessCity: OperatingCityName;
  businessAddress: string;
  complianceAccepted: boolean;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  destinationCity: OperatingCityName;
  destinationAddress: string;
  status: ShipmentStatus;
  statusNote: string;
  price: number;
  currentLocation: string;
  currentLat: number;
  currentLng: number;
  createdAt: string;
  updatedAt: string;
};

export type TrackingEventRecord = {
  id: string;
  shipmentId: string;
  trackingCode: string;
  status: ShipmentStatus;
  location: string;
  note: string;
  lat: number;
  lng: number;
  createdAt: string;
};

export type NotificationRecord = {
  id: string;
  shipmentId: string;
  trackingCode: string;
  businessId: string;
  city: OperatingCityName;
  message: string;
  isContacted: boolean;
  createdAt: string;
};

export type AppStore = {
  users: UserRecord[];
  sessions: SessionRecord[];
  pricing: PricingRecord[];
  shipments: ShipmentRecord[];
  trackingEvents: TrackingEventRecord[];
  notifications: NotificationRecord[];
};

export type QueueSignal = {
  city: OperatingCityName;
  count: number;
  threshold: number;
  price: number;
  signal: "green" | "orange";
};

export type CenterNotification = NotificationRecord & {
  shipmentStatus: ShipmentStatus;
  businessName: string;
};

export type CenterSnapshot = {
  pricing: PricingRecord[];
  activeShipments: ShipmentRecord[];
  queueByCity: QueueSignal[];
  notifications: CenterNotification[];
  totals: {
    businesses: number;
    activeShipments: number;
    deliveredShipments: number;
    openNotifications: number;
  };
};

export type TrackingSnapshot = {
  shipment: ShipmentRecord;
  events: TrackingEventRecord[];
};

export type RegisterBusinessInput = {
  contactName: string;
  businessName: string;
  email: string;
  password: string;
  phone: string;
  city: OperatingCityName;
  address: string;
};

export type ShipmentInput = {
  businessName: string;
  businessEmail: string;
  businessPhone: string;
  businessCity: OperatingCityName;
  businessAddress: string;
  complianceAccepted: boolean;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  destinationCity: OperatingCityName;
  destinationAddress: string;
};

export type TelemetryUpdateInput = {
  trackingCode: string;
  status?: ShipmentStatus;
  location?: string;
  note?: string;
  lat?: number;
  lng?: number;
};

let mutationQueue: Promise<unknown> = Promise.resolve();

function createSeedStore(): AppStore {
  const adminCreatedAt = new Date().toISOString();
  return {
    users: [
      {
        id: randomUUID(),
        role: "admin",
        contactName: "Sfera Admin",
        businessName: "Sfera Express Delivery",
        email: DEFAULT_ADMIN_EMAIL.toLowerCase(),
        passwordHash: hashPassword(DEFAULT_ADMIN_PASSWORD),
        phone: "+355 69 000 0000",
        city: "Tirane",
        address: "Qendra operative, Tirane",
        createdAt: adminCreatedAt,
      },
    ],
    sessions: [],
    pricing: OPERATING_CITIES.map((city) => ({
      city: city.name,
      price: city.basePrice,
      threshold: city.threshold,
    })),
    shipments: [],
    trackingEvents: [],
    notifications: [],
  };
}

async function ensureStoreFile() {
  await mkdir(DATA_DIR, { recursive: true });
  try {
    await readFile(DATA_FILE, "utf8");
  } catch {
    await writeFile(DATA_FILE, JSON.stringify(createSeedStore(), null, 2), "utf8");
  }
}

function hydrateStore(parsed: AppStore): AppStore {
  const pricing = OPERATING_CITIES.map((city) => {
    const match = parsed.pricing.find((entry) => entry.city === city.name);
    return {
      city: city.name,
      price: match?.price ?? city.basePrice,
      threshold: match?.threshold ?? city.threshold,
    };
  });

  return {
    users: parsed.users ?? [],
    sessions: parsed.sessions ?? [],
    pricing,
    shipments: parsed.shipments ?? [],
    trackingEvents: parsed.trackingEvents ?? [],
    notifications: parsed.notifications ?? [],
  };
}

export async function readStore(): Promise<AppStore> {
  await ensureStoreFile();
  const raw = await readFile(DATA_FILE, "utf8");
  return hydrateStore(JSON.parse(raw) as AppStore);
}

async function writeStore(store: AppStore) {
  await writeFile(DATA_FILE, JSON.stringify(store, null, 2), "utf8");
}

export async function mutateStore<T>(
  mutation: (store: AppStore) => Promise<T> | T,
): Promise<T> {
  const run = async () => {
    const store = await readStore();
    const result = await mutation(store);
    await writeStore(store);
    return result;
  };

  const next = mutationQueue.then(run, run) as Promise<T>;
  mutationQueue = next.then(
    () => undefined,
    () => undefined,
  );

  return next;
}

export function sanitizeEmail(value: string) {
  return value.trim().toLowerCase();
}

export function validateEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export function getPricingForCity(
  pricing: PricingRecord[],
  city: OperatingCityName,
) {
  return pricing.find((item) => item.city === city) ?? {
    city,
    price: getCityConfig(city).basePrice,
    threshold: getCityConfig(city).threshold,
  };
}

export async function createBusinessUser(input: RegisterBusinessInput) {
  return mutateStore((store) => {
    const email = sanitizeEmail(input.email);
    if (!validateEmail(email)) {
      throw new Error("Email-i nuk eshte valid.");
    }

    if (!isOperatingCity(input.city)) {
      throw new Error("Qyteti i zgjedhur nuk mbeshtetet.");
    }

    if (store.users.some((user) => user.email === email)) {
      throw new Error("Ky email ekziston tashme.");
    }

    if (
      !input.contactName.trim() ||
      !input.businessName.trim() ||
      !input.phone.trim() ||
      !input.address.trim()
    ) {
      throw new Error("Ploteso te gjitha fushat e regjistrimit.");
    }

    if (input.password.trim().length < 8) {
      throw new Error("Fjalekalimi duhet te kete te pakten 8 karaktere.");
    }

    const now = new Date().toISOString();
    const user: UserRecord = {
      id: randomUUID(),
      role: "business",
      contactName: input.contactName.trim(),
      businessName: input.businessName.trim(),
      email,
      passwordHash: hashPassword(input.password),
      phone: input.phone.trim(),
      city: input.city,
      address: input.address.trim(),
      createdAt: now,
    };

    store.users.push(user);
    return user;
  });
}

export async function authenticateUser(email: string, password: string) {
  const store = await readStore();
  const normalizedEmail = sanitizeEmail(email);
  const user = store.users.find((entry) => entry.email === normalizedEmail);

  if (!user || !verifyPassword(password, user.passwordHash)) {
    return null;
  }

  return user;
}

export async function createSession(userId: string, token: string) {
  return mutateStore((store) => {
    store.sessions = store.sessions.filter((session) => session.userId !== userId);
    store.sessions.push({
      id: randomUUID(),
      userId,
      token,
      createdAt: new Date().toISOString(),
    });
  });
}

export async function deleteSession(token: string) {
  return mutateStore((store) => {
    store.sessions = store.sessions.filter((session) => session.token !== token);
  });
}

export async function getUserBySession(token: string) {
  const store = await readStore();
  const session = store.sessions.find((entry) => entry.token === token);
  if (!session) {
    return null;
  }

  return store.users.find((user) => user.id === session.userId) ?? null;
}

export async function updateBusinessProfile(
  userId: string,
  updates: Omit<RegisterBusinessInput, "password">,
) {
  return mutateStore((store) => {
    const user = store.users.find((entry) => entry.id === userId && entry.role === "business");
    if (!user) {
      throw new Error("Profili i biznesit nuk u gjet.");
    }

    const email = sanitizeEmail(updates.email);
    if (!validateEmail(email)) {
      throw new Error("Email-i nuk eshte valid.");
    }

    if (store.users.some((entry) => entry.email === email && entry.id !== user.id)) {
      throw new Error("Ky email perdoret nga nje llogari tjeter.");
    }

    if (
      !updates.contactName.trim() ||
      !updates.businessName.trim() ||
      !updates.phone.trim() ||
      !updates.address.trim()
    ) {
      throw new Error("Ploteso te gjitha fushat e profilit.");
    }

    user.contactName = updates.contactName.trim();
    user.businessName = updates.businessName.trim();
    user.email = email;
    user.phone = updates.phone.trim();
    user.city = updates.city;
    user.address = updates.address.trim();

    store.shipments = store.shipments.map((shipment) =>
      shipment.businessId === user.id
        ? {
            ...shipment,
            businessName: user.businessName,
            businessEmail: user.email,
            businessPhone: user.phone,
            businessCity: user.city,
            businessAddress: user.address,
          }
        : shipment,
    );

    return user;
  });
}

function generateTrackingCode(store: AppStore, destinationCity: OperatingCityName) {
  let nextCode = "";
  do {
    nextCode = `SFE-${cityCode(destinationCity)}-${randomUUID().slice(0, 6).toUpperCase()}`;
  } while (store.shipments.some((shipment) => shipment.trackingCode === nextCode));

  return nextCode;
}

export async function createShipmentForBusiness(
  businessUser: UserRecord,
  input: ShipmentInput,
) {
  return mutateStore((store) => {
    if (!input.complianceAccepted) {
      throw new Error("Duhet te pranosh pajtueshmerine per dergesen.");
    }

    if (!isOperatingCity(input.destinationCity)) {
      throw new Error("Qyteti i destinacionit nuk mbeshtetet.");
    }

    if (!isOperatingCity(input.businessCity)) {
      throw new Error("Qyteti i biznesit nuk mbeshtetet.");
    }

    if (
      !input.businessName.trim() ||
      !input.businessPhone.trim() ||
      !input.businessAddress.trim() ||
      !input.customerName.trim() ||
      !input.customerPhone.trim() ||
      !input.customerEmail.trim() ||
      !input.destinationAddress.trim()
    ) {
      throw new Error("Ploteso te gjitha fushat e dergeses.");
    }

    if (!validateEmail(input.businessEmail) || !validateEmail(input.customerEmail)) {
      throw new Error("Email-i i biznesit ose i klientit nuk eshte valid.");
    }

    const now = new Date().toISOString();
    const pricing = getPricingForCity(store.pricing, input.destinationCity);
    const code = generateTrackingCode(store, input.destinationCity);
    const originHub = getCityConfig(input.businessCity);

    const shipment: ShipmentRecord = {
      id: randomUUID(),
      trackingCode: code,
      businessId: businessUser.id,
      businessName: input.businessName.trim(),
      businessEmail: sanitizeEmail(input.businessEmail),
      businessPhone: input.businessPhone.trim(),
      businessCity: input.businessCity,
      businessAddress: input.businessAddress.trim(),
      complianceAccepted: input.complianceAccepted,
      customerName: input.customerName.trim(),
      customerPhone: input.customerPhone.trim(),
      customerEmail: sanitizeEmail(input.customerEmail),
      destinationCity: input.destinationCity,
      destinationAddress: input.destinationAddress.trim(),
      status: SHIPMENT_STATUSES[0],
      statusNote: "Kerkesa u dergua ne qender dhe pret konfirmimin per pickup.",
      price: pricing.price,
      currentLocation: `Pickup ne pritje te biznesi ne ${input.businessCity}`,
      currentLat: originHub.lat,
      currentLng: originHub.lng,
      createdAt: now,
      updatedAt: now,
    };

    const event: TrackingEventRecord = {
      id: randomUUID(),
      shipmentId: shipment.id,
      trackingCode: shipment.trackingCode,
      status: shipment.status,
      location: shipment.currentLocation,
      note: shipment.statusNote,
      lat: shipment.currentLat,
      lng: shipment.currentLng,
      createdAt: now,
    };

    const notification: NotificationRecord = {
      id: randomUUID(),
      shipmentId: shipment.id,
      trackingCode: shipment.trackingCode,
      businessId: businessUser.id,
      city: shipment.destinationCity,
      message: `${shipment.businessName} kerkoi dergese te re per ${shipment.destinationCity}.`,
      isContacted: false,
      createdAt: now,
    };

    store.shipments.unshift(shipment);
    store.trackingEvents.unshift(event);
    store.notifications.unshift(notification);

    return shipment;
  });
}

export async function updatePricingRecords(records: PricingRecord[]) {
  return mutateStore((store) => {
    store.pricing = OPERATING_CITY_NAMES.map((city) => {
      const incoming = records.find((item) => item.city === city);
      const fallback = getPricingForCity(store.pricing, city);
      return {
        city,
        price: incoming?.price ?? fallback.price,
        threshold: incoming?.threshold ?? fallback.threshold,
      };
    });
  });
}

export async function updateShipmentProgress(input: TelemetryUpdateInput) {
  return mutateStore((store) => {
    const shipment = store.shipments.find(
      (entry) => entry.trackingCode === input.trackingCode.trim().toUpperCase(),
    );

    if (!shipment) {
      throw new Error("Kodi i gjurmimit nuk u gjet.");
    }

    const destinationHub = getCityConfig(shipment.destinationCity);
    const now = new Date().toISOString();

    shipment.status = input.status ?? shipment.status;
    shipment.statusNote = input.note?.trim() || shipment.statusNote;
    shipment.currentLocation = input.location?.trim() || shipment.currentLocation;
    shipment.currentLat = input.lat ?? shipment.currentLat ?? destinationHub.lat;
    shipment.currentLng = input.lng ?? shipment.currentLng ?? destinationHub.lng;
    shipment.updatedAt = now;

    store.trackingEvents.unshift({
      id: randomUUID(),
      shipmentId: shipment.id,
      trackingCode: shipment.trackingCode,
      status: shipment.status,
      location: shipment.currentLocation,
      note: shipment.statusNote,
      lat: shipment.currentLat,
      lng: shipment.currentLng,
      createdAt: now,
    });

    if (shipment.status !== "Kerkese e re") {
      store.notifications = store.notifications.map((notification) =>
        notification.shipmentId === shipment.id
          ? { ...notification, isContacted: true }
          : notification,
      );
    }

    return shipment;
  });
}

export async function getShipmentByTrackingCode(trackingCode: string) {
  const store = await readStore();
  const code = trackingCode.trim().toUpperCase();
  const shipment = store.shipments.find((entry) => entry.trackingCode === code);
  if (!shipment) {
    return null;
  }

  const events = store.trackingEvents
    .filter((event) => event.shipmentId === shipment.id)
    .sort((a, b) => (a.createdAt > b.createdAt ? -1 : 1));

  return { shipment, events } satisfies TrackingSnapshot;
}

export async function getBusinessShipments(userId: string) {
  const store = await readStore();
  return store.shipments
    .filter((shipment) => shipment.businessId === userId)
    .sort((a, b) => (a.createdAt > b.createdAt ? -1 : 1));
}

export async function getPricingSnapshot() {
  const store = await readStore();
  return store.pricing;
}

export async function getCenterSnapshot() {
  const store = await readStore();

  const activeShipments = store.shipments
    .filter((shipment) => shipment.status !== "Dorezuar")
    .sort((a, b) => (a.updatedAt > b.updatedAt ? -1 : 1));

  const queueByCity: QueueSignal[] = store.pricing.map((price) => {
    const total = activeShipments.filter(
      (shipment) => shipment.destinationCity === price.city,
    ).length;

    return {
      city: price.city,
      count: total,
      threshold: price.threshold,
      price: price.price,
      signal: total >= price.threshold ? "green" : "orange",
    };
  });

  const unreadNotifications = store.notifications
    .slice()
    .sort((a, b) => (a.createdAt > b.createdAt ? -1 : 1))
    .slice(0, 12)
    .map((notification) => {
      const shipment = store.shipments.find((entry) => entry.id === notification.shipmentId);
      const business = store.users.find((entry) => entry.id === notification.businessId);

      return {
        ...notification,
        shipmentStatus: shipment?.status ?? "Kerkese e re",
        businessName: business?.businessName ?? shipment?.businessName ?? "Biznes",
      };
    });

  return {
    pricing: store.pricing,
    activeShipments,
    queueByCity,
    notifications: unreadNotifications,
    totals: {
      businesses: store.users.filter((user) => user.role === "business").length,
      activeShipments: activeShipments.length,
      deliveredShipments: store.shipments.filter(
        (shipment) => shipment.status === "Dorezuar",
      ).length,
      openNotifications: store.notifications.filter((notification) => !notification.isContacted)
        .length,
    },
  } satisfies CenterSnapshot;
}

export async function getPublicStatusSnapshot() {
  const store = await readStore();
  const activeShipments = store.shipments.filter(
    (shipment) => shipment.status !== "Dorezuar",
  ).length;

  return {
    company: "Sfera Express Delivery",
    domain: "sferaexpress.al",
    generatedAt: new Date().toISOString(),
    businesses: store.users.filter((user) => user.role === "business").length,
    activeShipments,
    operatingCities: store.pricing,
  };
}
