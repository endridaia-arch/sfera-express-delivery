type SectionTitleProps = {
  eyebrow: string;
  title: string;
  description: string;
  inverse?: boolean;
};

export function SectionTitle({
  eyebrow,
  title,
  description,
  inverse = false,
}: SectionTitleProps) {
  return (
    <div className="max-w-2xl">
      <p
        className={`font-mono text-xs uppercase tracking-[0.32em] ${
          inverse ? "text-white/55" : "text-[var(--accent)]"
        }`}
      >
        {eyebrow}
      </p>
      <h2
        className={`mt-4 font-heading text-3xl leading-tight font-semibold sm:text-4xl ${
          inverse ? "text-white" : "text-[var(--foreground)]"
        }`}
      >
        {title}
      </h2>
      <p
        className={`mt-4 max-w-xl text-base leading-7 ${
          inverse ? "text-white/72" : "text-[var(--muted)]"
        }`}
      >
        {description}
      </p>
    </div>
  );
}
