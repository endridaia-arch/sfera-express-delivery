"use client";

import { useActionState } from "react";
import { updateProfileAction, type FormState } from "@/app/actions";
import { OPERATING_CITY_NAMES } from "@/lib/constants";
import type { UserRecord } from "@/lib/store";

const initialState: FormState = {};

export function ProfileForm({ user }: { user: UserRecord }) {
  const [state, formAction] = useActionState(updateProfileAction, initialState);

  return (
    <form action={formAction} className="grid gap-4">
      <div className="grid gap-4 md:grid-cols-2">
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Emri i kontaktit</span>
          <input
            name="contactName"
            defaultValue={user.contactName}
            required
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
          />
        </label>
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Emri i biznesit</span>
          <input
            name="businessName"
            defaultValue={user.businessName}
            required
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
          />
        </label>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Email</span>
          <input
            name="email"
            type="email"
            defaultValue={user.email}
            required
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
          />
        </label>
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Numer telefoni</span>
          <input
            name="phone"
            defaultValue={user.phone}
            required
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
          />
        </label>
      </div>

      <label className="grid gap-2 text-sm text-[var(--foreground)]">
        <span>Qyteti</span>
        <select
          name="city"
          defaultValue={user.city}
          className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
        >
          {OPERATING_CITY_NAMES.map((city) => (
            <option key={city} value={city}>
              {city}
            </option>
          ))}
        </select>
      </label>

      <label className="grid gap-2 text-sm text-[var(--foreground)]">
        <span>Adresa e sakte</span>
        <textarea
          name="address"
          rows={4}
          defaultValue={user.address}
          required
          className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
        />
      </label>

      {state.error ? (
        <p className="rounded-2xl bg-[var(--accent-strong)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
          {state.error}
        </p>
      ) : null}

      {state.success ? (
        <p className="rounded-2xl bg-[var(--accent)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
          {state.success}
        </p>
      ) : null}

      <button
        type="submit"
        className="w-fit rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)] transition hover:bg-[var(--panel-soft)]"
      >
        Ruaj profilin
      </button>
    </form>
  );
}
