"use client";

import Link from "next/link";
import { startTransition, useMemo, useState } from "react";
import { formatLek, OPERATING_CITY_NAMES } from "@/lib/constants";
import type { PricingRecord, UserRecord } from "@/lib/store";

type WizardState = {
  businessName: string;
  businessEmail: string;
  businessPhone: string;
  businessCity: string;
  businessAddress: string;
  complianceAccepted: boolean;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  destinationCity: string;
  destinationAddress: string;
};

export function ShipmentWizard({
  user,
  pricing,
}: {
  user: UserRecord;
  pricing: PricingRecord[];
}) {
  const [step, setStep] = useState<1 | 2>(1);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [created, setCreated] = useState<{ trackingCode: string; price: number } | null>(null);
  const [copied, setCopied] = useState(false);
  const [form, setForm] = useState<WizardState>({
    businessName: user.businessName,
    businessEmail: user.email,
    businessPhone: user.phone,
    businessCity: user.city,
    businessAddress: user.address,
    complianceAccepted: false,
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    destinationCity: "Tirane",
    destinationAddress: "",
  });

  const currentPrice = useMemo(() => {
    const match = pricing.find((item) => item.city === form.destinationCity);
    return match?.price ?? 0;
  }, [form.destinationCity, pricing]);

  function updateField<K extends keyof WizardState>(key: K, value: WizardState[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function submitShipment() {
    setIsSubmitting(true);
    setError("");

    try {
      const response = await fetch("/api/shipments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const payload = (await response.json()) as
        | { error: string }
        | { trackingCode: string; price: number };

      if (!response.ok || "error" in payload) {
        throw new Error("error" in payload ? payload.error : "Dergesa nuk u krijua.");
      }

      setCreated(payload);
    } catch (submitError) {
      setError(
        submitError instanceof Error ? submitError.message : "Dergesa nuk u krijua.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  if (created) {
    const shareMessage = `Pershendetje ${form.customerName}, porosia juaj nga ${form.businessName} eshte regjistruar te Sfera Express Delivery. Kodi i gjurmimit: ${created.trackingCode}. Ndiqeni ne kohe reale te sferaexpress.al/track/${created.trackingCode}.`;

    return (
      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)] backdrop-blur-sm">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
          Dergesa u krijua
        </p>
        <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
          Kodi i gjurmimit eshte gati
        </h2>
        <div className="mt-6 rounded-[1.75rem] border border-black/6 bg-[var(--surface-strong)] p-6">
          <p className="text-sm text-[var(--muted)]">Tracking code</p>
          <p className="mt-2 font-mono text-3xl font-semibold text-[var(--foreground)]">
            {created.trackingCode}
          </p>
          <p className="mt-4 text-sm leading-6 text-[var(--muted)]">
            Qendra mori kerkesen. Biznesi do te kontaktohet per pickup dhe afatin e
            dorezimit. Kostoja e zgjedhur eshte {formatLek(created.price)}.
          </p>
        </div>
        <div className="mt-5 rounded-[1.75rem] border border-black/6 bg-[var(--surface-strong)] p-5">
          <p className="text-sm font-semibold text-[var(--foreground)]">
            Mesazh gati per klientin
          </p>
          <p className="mt-3 text-sm leading-6 text-[var(--muted)]">{shareMessage}</p>
          <button
            type="button"
            onClick={async () => {
              await navigator.clipboard.writeText(shareMessage);
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1800);
            }}
            className="mt-4 rounded-full border border-black/8 px-4 py-2 text-sm font-semibold text-[var(--foreground)]"
          >
            {copied ? "U kopjua" : "Kopjo mesazhin"}
          </button>
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            href={`/track/${created.trackingCode}`}
            className="rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)]"
          >
            Ndiq dergesen
          </Link>
          <button
            type="button"
            onClick={() =>
              startTransition(() => {
                setCreated(null);
                setCopied(false);
                setStep(1);
                setForm((current) => ({
                  ...current,
                  customerName: "",
                  customerPhone: "",
                  customerEmail: "",
                  destinationCity: "Tirane",
                  destinationAddress: "",
                }));
              })
            }
            className="rounded-full border border-black/8 px-5 py-3 text-sm font-semibold text-[var(--foreground)]"
          >
            Krijo nje tjeter
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="rounded-[2rem] border border-black/6 bg-white/82 p-8 shadow-[0_22px_70px_rgba(20,35,46,0.08)] backdrop-blur-sm">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
            Dergese e re
          </p>
          <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
            Rrjedha ne dy hapa
          </h2>
        </div>
        <div className="rounded-full border border-black/8 px-4 py-2 text-sm text-[var(--foreground)]">
          Hapi {step} / 2
        </div>
      </div>

      {step === 1 ? (
        <div className="mt-8 grid gap-4">
          <label className="grid gap-2 text-sm text-[var(--foreground)]">
            <span>Emri i biznesit</span>
            <input
              value={form.businessName}
              onChange={(event) => updateField("businessName", event.target.value)}
              className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
            />
          </label>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Email</span>
              <input
                value={form.businessEmail}
                onChange={(event) => updateField("businessEmail", event.target.value)}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
              />
            </label>
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Numer telefoni</span>
              <input
                value={form.businessPhone}
                onChange={(event) => updateField("businessPhone", event.target.value)}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
              />
            </label>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Qyteti i biznesit</span>
              <select
                value={form.businessCity}
                onChange={(event) => updateField("businessCity", event.target.value)}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
              >
                {OPERATING_CITY_NAMES.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Adresa e sakte</span>
              <input
                value={form.businessAddress}
                onChange={(event) => updateField("businessAddress", event.target.value)}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
              />
            </label>
          </div>
          <label className="flex items-start gap-3 rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] px-4 py-4 text-sm leading-6 text-[var(--foreground)]">
            <input
              checked={form.complianceAccepted}
              onChange={(event) => updateField("complianceAccepted", event.target.checked)}
              type="checkbox"
              className="mt-1 h-4 w-4 accent-[var(--accent)]"
            />
            <span>
              Pranoj pajtueshmerine per dergesat dhe konfirmoj qe te dhenat e biznesit
              jane te sakta.
            </span>
          </label>
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => {
                if (!form.complianceAccepted) {
                  setError("Prano pajtueshmerine per te vazhduar.");
                  return;
                }
                setError("");
                setStep(2);
              }}
              className="rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)]"
            >
              Vazhdoni
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-8 grid gap-4">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Emri i klientit</span>
              <input
                value={form.customerName}
                onChange={(event) => updateField("customerName", event.target.value)}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
              />
            </label>
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Numer telefoni</span>
              <input
                value={form.customerPhone}
                onChange={(event) => updateField("customerPhone", event.target.value)}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
              />
            </label>
          </div>
          <label className="grid gap-2 text-sm text-[var(--foreground)]">
            <span>Email i klientit</span>
            <input
              value={form.customerEmail}
              onChange={(event) => updateField("customerEmail", event.target.value)}
              className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
            />
          </label>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Qyteti i destinacionit</span>
              <select
                value={form.destinationCity}
                onChange={(event) => updateField("destinationCity", event.target.value)}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
              >
                {OPERATING_CITY_NAMES.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </label>
            <div className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] px-4 py-4">
              <p className="text-sm text-[var(--muted)]">Kosto aktuale per destinacionin</p>
              <p className="mt-2 font-heading text-3xl font-semibold text-[var(--foreground)]">
                {formatLek(currentPrice)}
              </p>
            </div>
          </div>
          <label className="grid gap-2 text-sm text-[var(--foreground)]">
            <span>Adresa e klientit</span>
            <textarea
              rows={4}
              value={form.destinationAddress}
              onChange={(event) => updateField("destinationAddress", event.target.value)}
              className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none focus:border-[var(--accent)]"
            />
          </label>
          <div className="flex flex-wrap justify-between gap-3">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="rounded-full border border-black/8 px-5 py-3 text-sm font-semibold text-[var(--foreground)]"
            >
              Kthehu
            </button>
            <button
              type="button"
              onClick={() => void submitShipment()}
              disabled={isSubmitting}
              className="rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)] disabled:opacity-60"
            >
              {isSubmitting ? "Duke krijuar..." : "Konfirmo dergesen"}
            </button>
          </div>
        </div>
      )}

      {error ? (
        <p className="mt-5 rounded-2xl bg-[var(--accent-strong)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
          {error}
        </p>
      ) : null}
    </section>
  );
}
