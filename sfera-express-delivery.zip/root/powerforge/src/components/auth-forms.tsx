"use client";

import { useActionState } from "react";
import { loginAction, registerBusinessAction, type FormState } from "@/app/actions";
import { OPERATING_CITY_NAMES } from "@/lib/constants";

const initialState: FormState = {};

function SubmitButton({ label }: { label: string }) {
  return (
    <button
      type="submit"
      className="rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)] transition hover:bg-[var(--panel-soft)]"
    >
      {label}
    </button>
  );
}

function Field({
  label,
  name,
  type = "text",
  required = true,
  defaultValue,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  defaultValue?: string;
}) {
  return (
    <label className="grid gap-2 text-sm text-[var(--foreground)]">
      <span>{label}</span>
      <input
        name={name}
        type={type}
        defaultValue={defaultValue}
        required={required}
        className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
      />
    </label>
  );
}

export function AuthForms() {
  const [loginState, loginFormAction] = useActionState(loginAction, initialState);
  const [registerState, registerFormAction] = useActionState(
    registerBusinessAction,
    initialState,
  );

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-7 shadow-[0_22px_70px_rgba(20,35,46,0.08)] backdrop-blur-sm">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
          Hyr ne sistem
        </p>
        <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
          Login per biznes ose qender
        </h2>
        <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
          Bizneset hyjne me email-in e regjistruar. Qendra operative hyn me llogarine
          admin te sistemit.
        </p>

        <form action={loginFormAction} className="mt-6 grid gap-4">
          <Field label="Email" name="email" type="email" />
          <Field label="Fjalekalim" name="password" type="password" />
          {loginState.error ? (
            <p className="rounded-2xl bg-[var(--accent-strong)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
              {loginState.error}
            </p>
          ) : null}
          <SubmitButton label="Hyr ne panel" />
        </form>
      </section>

      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-7 shadow-[0_22px_70px_rgba(20,35,46,0.08)] backdrop-blur-sm">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
          Regjistro biznesin
        </p>
        <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
          Hap profilin e biznesit
        </h2>
        <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
          Pas regjistrimit, biznesi futet direkt ne profilin e vet dhe mund te krijoje
          dergesa ne kohe reale.
        </p>

        <form action={registerFormAction} className="mt-6 grid gap-4">
          <Field label="Emri i kontaktit" name="contactName" />
          <Field label="Emri i biznesit" name="businessName" />
          <Field label="Email / Gmail" name="email" type="email" />
          <Field label="Fjalekalim" name="password" type="password" />
          <Field label="Numer telefoni" name="phone" />
          <label className="grid gap-2 text-sm text-[var(--foreground)]">
            <span>Qyteti</span>
            <select
              name="city"
              required
              className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
              defaultValue="Tirane"
            >
              {OPERATING_CITY_NAMES.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </label>
          <label className="grid gap-2 text-sm text-[var(--foreground)]">
            <span>Adresa e sakte</span>
            <textarea
              name="address"
              rows={4}
              required
              className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none transition focus:border-[var(--accent)]"
            />
          </label>
          {registerState.error ? (
            <p className="rounded-2xl bg-[var(--accent-strong)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
              {registerState.error}
            </p>
          ) : null}
          <SubmitButton label="Regjistrohu" />
        </form>
      </section>
    </div>
  );
}
