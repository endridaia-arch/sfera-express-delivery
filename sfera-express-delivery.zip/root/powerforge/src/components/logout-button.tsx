"use client";

import { logoutAction } from "@/app/actions";

export function LogoutButton() {
  return (
    <form action={logoutAction}>
      <button
        type="submit"
        className="rounded-full border border-black/8 px-4 py-2 text-sm font-semibold text-[var(--foreground)] transition hover:bg-white"
      >
        Dil
      </button>
    </form>
  );
}
