"use client";

import { useEffect, useEffectEvent, useState } from "react";
import { formatLek } from "@/lib/constants";
import type { CenterSnapshot } from "@/lib/store";

export function LiveCenterBoard({
  initialSnapshot,
}: {
  initialSnapshot: CenterSnapshot;
}) {
  const [snapshot, setSnapshot] = useState(initialSnapshot);

  const refreshSnapshot = useEffectEvent(async () => {
    const response = await fetch("/api/center/live", { cache: "no-store" });
    if (!response.ok) {
      return;
    }

    const payload = (await response.json()) as CenterSnapshot;
    setSnapshot(payload);
  });

  useEffect(() => {
    const timer = setInterval(() => {
      void refreshSnapshot();
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="grid gap-6">
      <section className="grid gap-4 md:grid-cols-4">
        <article className="rounded-[1.75rem] border border-black/6 bg-white/80 p-5">
          <p className="text-sm text-[var(--muted)]">Biznese aktive</p>
          <p className="mt-2 font-heading text-4xl font-semibold text-[var(--foreground)]">
            {snapshot.totals.businesses}
          </p>
        </article>
        <article className="rounded-[1.75rem] border border-black/6 bg-white/80 p-5">
          <p className="text-sm text-[var(--muted)]">Dergesa aktive</p>
          <p className="mt-2 font-heading text-4xl font-semibold text-[var(--foreground)]">
            {snapshot.totals.activeShipments}
          </p>
        </article>
        <article className="rounded-[1.75rem] border border-black/6 bg-white/80 p-5">
          <p className="text-sm text-[var(--muted)]">Dergesa te dorezuara</p>
          <p className="mt-2 font-heading text-4xl font-semibold text-[var(--foreground)]">
            {snapshot.totals.deliveredShipments}
          </p>
        </article>
        <article className="rounded-[1.75rem] border border-black/6 bg-white/80 p-5">
          <p className="text-sm text-[var(--muted)]">Njoftime te hapura</p>
          <p className="mt-2 font-heading text-4xl font-semibold text-[var(--foreground)]">
            {snapshot.totals.openNotifications}
          </p>
        </article>
      </section>

      <section className="grid gap-5 lg:grid-cols-[1.06fr_0.94fr]">
        <div className="rounded-[2rem] border border-black/6 bg-white/80 p-7">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
            Qytetet ne operim
          </p>
          <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
            Sinjalet e destinacioneve
          </h2>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {snapshot.queueByCity.map((item) => (
              <article
                key={item.city}
                className={`rounded-[1.5rem] border p-5 ${
                  item.signal === "green"
                    ? "border-emerald-300 bg-emerald-50"
                    : "border-orange-300 bg-orange-50"
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <p className="font-heading text-2xl font-semibold text-[var(--foreground)]">
                    {item.city}
                  </p>
                  <span
                    className={`h-3 w-3 rounded-full ${
                      item.signal === "green" ? "bg-emerald-500" : "bg-orange-500"
                    }`}
                  />
                </div>
                <p className="mt-3 text-sm text-[var(--muted)]">
                  {item.count} dergesa aktive / pragu {item.threshold}
                </p>
                <p className="mt-3 text-sm text-[var(--muted)]">
                  Tarifa aktuale: {formatLek(item.price)}
                </p>
                <p
                  className={`mt-4 rounded-full px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] ${
                    item.signal === "green"
                      ? "bg-emerald-600 text-white"
                      : "bg-orange-500 text-white"
                  }`}
                >
                  {item.signal === "green"
                    ? "Nisu per pickup ne kete qytet"
                    : "Ne pritje te volumit te plote"}
                </p>
              </article>
            ))}
          </div>
        </div>

        <div className="rounded-[2rem] border border-white/12 bg-[var(--panel)] p-7 text-white">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-white/55">
            Njoftime live
          </p>
          <h2 className="mt-4 font-heading text-3xl font-semibold">Qendra operative</h2>
          <div className="mt-6 space-y-4">
            {snapshot.notifications.length === 0 ? (
              <p className="rounded-[1.5rem] border border-white/10 bg-white/6 px-4 py-4 text-sm text-white/70">
                Nuk ka kerkesa te reja per momentin.
              </p>
            ) : (
              snapshot.notifications.map((item) => (
                <article
                  key={item.id}
                  className="rounded-[1.5rem] border border-white/10 bg-white/6 p-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="font-heading text-lg font-semibold">{item.businessName}</p>
                    <span className="font-mono text-xs uppercase tracking-[0.22em] text-white/55">
                      {item.city}
                    </span>
                  </div>
                  <p className="mt-3 text-sm leading-6 text-white/72">{item.message}</p>
                  <p className="mt-3 text-xs uppercase tracking-[0.2em] text-white/50">
                    {item.trackingCode} / {item.shipmentStatus}
                  </p>
                </article>
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
