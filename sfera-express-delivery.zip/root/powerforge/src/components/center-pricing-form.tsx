"use client";

import { useActionState } from "react";
import { updatePricingAction, type FormState } from "@/app/actions";
import { formatLek } from "@/lib/constants";
import type { PricingRecord } from "@/lib/store";

const initialState: FormState = {};

export function CenterPricingForm({ pricing }: { pricing: PricingRecord[] }) {
  const [state, formAction] = useActionState(updatePricingAction, initialState);

  return (
    <form action={formAction} className="grid gap-4">
      <div className="grid gap-4">
        {pricing.map((item) => (
          <div
            key={item.city}
            className="grid gap-4 rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5 md:grid-cols-[1.2fr_1fr_1fr]"
          >
            <div>
              <p className="font-heading text-2xl font-semibold text-[var(--foreground)]">
                {item.city}
              </p>
              <p className="mt-2 text-sm text-[var(--muted)]">
                Tarifa aktuale: {formatLek(item.price)}
              </p>
            </div>
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Cmimi (ALL)</span>
              <input
                type="number"
                name={`price-${item.city}`}
                min={0}
                defaultValue={item.price}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none"
              />
            </label>
            <label className="grid gap-2 text-sm text-[var(--foreground)]">
              <span>Pragu jeshil</span>
              <input
                type="number"
                name={`threshold-${item.city}`}
                min={1}
                defaultValue={item.threshold}
                className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none"
              />
            </label>
          </div>
        ))}
      </div>

      {state.error ? (
        <p className="rounded-2xl bg-[var(--accent-strong)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
          {state.error}
        </p>
      ) : null}
      {state.success ? (
        <p className="rounded-2xl bg-[var(--accent)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
          {state.success}
        </p>
      ) : null}
      <button
        type="submit"
        className="w-fit rounded-full bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--surface-strong)]"
      >
        Ruaj tarifat
      </button>
    </form>
  );
}
