import Link from "next/link";

export function PortalFab() {
  return (
    <Link
      href="/portal/create"
      className="fixed bottom-6 left-1/2 z-30 grid h-16 w-16 -translate-x-1/2 place-items-center rounded-full bg-[var(--accent-strong)] text-4xl font-semibold text-white shadow-[0_24px_60px_rgba(239,111,67,0.36)] transition hover:scale-[1.04]"
      aria-label="Krijo dergese te re"
    >
      +
    </Link>
  );
}
