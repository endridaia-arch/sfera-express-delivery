"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";

export function TrackingSearch() {
  const router = useRouter();
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [isPending, startTransition] = useTransition();

  return (
    <form
      className="flex flex-col gap-3 rounded-[1.75rem] border border-white/12 bg-[var(--panel)] p-4 shadow-[0_28px_90px_rgba(8,14,24,0.24)] sm:flex-row sm:items-center"
      onSubmit={(event) => {
        event.preventDefault();
        const value = code.trim().toUpperCase();
        if (!value) {
          setError("Shkruaj kodin e gjurmimit.");
          return;
        }

        setError("");
        startTransition(() => {
          router.push(`/track/${value}`);
        });
      }}
    >
      <div className="flex-1">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-white/55">
          Motor kerkimi sferaexpress.al / tracking
        </p>
        <input
          value={code}
          onChange={(event) => setCode(event.target.value)}
          placeholder="Shembull: SFE-TIR-AB12CD"
          className="mt-3 w-full rounded-2xl border border-white/10 bg-white/8 px-4 py-3 text-white outline-none placeholder:text-white/45 focus:border-[var(--accent)]"
        />
      </div>
      <button
        type="submit"
        disabled={isPending}
        className="rounded-full bg-white px-5 py-3 text-sm font-semibold text-[var(--panel)] transition hover:bg-[var(--surface-strong)] disabled:opacity-60"
      >
        Kerko dergesen
      </button>
      {error ? <p className="text-sm text-white/75">{error}</p> : null}
    </form>
  );
}
