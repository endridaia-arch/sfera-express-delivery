"use client";

import { useEffect, useEffectEvent, useState } from "react";
import type { TrackingSnapshot } from "@/lib/store";

export function LiveTrackingPanel({
  trackingCode,
  initialSnapshot,
}: {
  trackingCode: string;
  initialSnapshot: TrackingSnapshot;
}) {
  const [snapshot, setSnapshot] = useState(initialSnapshot);

  const refreshTracking = useEffectEvent(async () => {
    const response = await fetch(`/api/tracking/${trackingCode}`, { cache: "no-store" });
    if (!response.ok) {
      return;
    }

    const payload = (await response.json()) as TrackingSnapshot;
    setSnapshot(payload);
  });

  useEffect(() => {
    const timer = setInterval(() => {
      void refreshTracking();
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const latest = snapshot.shipment;

  return (
    <div className="grid gap-6 lg:grid-cols-[0.98fr_1.02fr]">
      <section className="rounded-[2rem] border border-black/6 bg-white/82 p-7 shadow-[0_22px_70px_rgba(20,35,46,0.08)]">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-[var(--accent)]">
          Tracking live
        </p>
        <h2 className="mt-4 font-heading text-3xl font-semibold text-[var(--foreground)]">
          {latest.trackingCode}
        </h2>
        <div className="mt-6 grid gap-4">
          <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5">
            <p className="text-sm text-[var(--muted)]">Statusi aktual</p>
            <p className="mt-2 font-heading text-2xl font-semibold text-[var(--foreground)]">
              {latest.status}
            </p>
            <p className="mt-3 text-sm leading-6 text-[var(--muted)]">{latest.statusNote}</p>
          </article>
          <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5">
            <p className="text-sm text-[var(--muted)]">Vendndodhja aktuale</p>
            <p className="mt-2 font-heading text-2xl font-semibold text-[var(--foreground)]">
              {latest.currentLocation}
            </p>
            <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
              GPS: {latest.currentLat.toFixed(4)}, {latest.currentLng.toFixed(4)}
            </p>
          </article>
          <article className="rounded-[1.5rem] border border-black/6 bg-[var(--surface-strong)] p-5">
            <p className="text-sm text-[var(--muted)]">Klienti final</p>
            <p className="mt-2 text-base font-semibold text-[var(--foreground)]">
              {latest.customerName}
            </p>
            <p className="mt-2 text-sm text-[var(--muted)]">
              {latest.destinationCity} / {latest.destinationAddress}
            </p>
          </article>
        </div>
      </section>

      <section className="rounded-[2rem] border border-white/12 bg-[var(--panel)] p-7 text-white shadow-[0_28px_90px_rgba(8,14,24,0.24)]">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-white/55">
          Kronologjia e levizjes
        </p>
        <h2 className="mt-4 font-heading text-3xl font-semibold">Historiku i dergeses</h2>
        <div className="mt-6 space-y-4">
          {snapshot.events.map((event) => (
            <article
              key={event.id}
              className="rounded-[1.5rem] border border-white/10 bg-white/6 p-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="font-heading text-lg font-semibold">{event.status}</p>
                <span className="font-mono text-xs uppercase tracking-[0.22em] text-white/55">
                  {new Date(event.createdAt).toLocaleString("sq-AL", {
                    hour: "2-digit",
                    minute: "2-digit",
                    day: "2-digit",
                    month: "short",
                  })}
                </span>
              </div>
              <p className="mt-3 text-sm leading-6 text-white/72">{event.location}</p>
              <p className="mt-3 text-sm leading-6 text-white/60">{event.note}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
