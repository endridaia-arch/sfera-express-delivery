"use client";

import { useActionState } from "react";
import { updateShipmentProgressAction, type FormState } from "@/app/actions";
import { SHIPMENT_STATUSES } from "@/lib/constants";
import type { ShipmentRecord } from "@/lib/store";

const initialState: FormState = {};

export function ShipmentProgressForm({ shipment }: { shipment: ShipmentRecord }) {
  const [state, formAction] = useActionState(updateShipmentProgressAction, initialState);

  return (
    <form action={formAction} className="grid gap-3">
      <input type="hidden" name="trackingCode" value={shipment.trackingCode} />
      <div className="grid gap-3 md:grid-cols-2">
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Statusi</span>
          <select
            name="status"
            defaultValue={shipment.status}
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none"
          >
            {SHIPMENT_STATUSES.map((status) => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </select>
        </label>
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Vendndodhja aktuale</span>
          <input
            name="currentLocation"
            defaultValue={shipment.currentLocation}
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none"
          />
        </label>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Latitude</span>
          <input
            name="currentLat"
            type="number"
            step="0.0001"
            defaultValue={shipment.currentLat}
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none"
          />
        </label>
        <label className="grid gap-2 text-sm text-[var(--foreground)]">
          <span>Longitude</span>
          <input
            name="currentLng"
            type="number"
            step="0.0001"
            defaultValue={shipment.currentLng}
            className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none"
          />
        </label>
      </div>

      <label className="grid gap-2 text-sm text-[var(--foreground)]">
        <span>Shenim per biznesin / klientin</span>
        <textarea
          name="statusNote"
          rows={3}
          defaultValue={shipment.statusNote}
          className="rounded-2xl border border-black/8 bg-white px-4 py-3 outline-none"
        />
      </label>

      {state.error ? (
        <p className="rounded-2xl bg-[var(--accent-strong)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
          {state.error}
        </p>
      ) : null}
      {state.success ? (
        <p className="rounded-2xl bg-[var(--accent)]/12 px-4 py-3 text-sm text-[var(--foreground)]">
          {state.success}
        </p>
      ) : null}

      <button
        type="submit"
        className="w-fit rounded-full bg-[var(--panel)] px-4 py-2 text-sm font-semibold text-[var(--surface-strong)]"
      >
        Perditeso tracking-un
      </button>
    </form>
  );
}
